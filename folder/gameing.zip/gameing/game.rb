require 'ruby2d'

set width: 600
set height: 600

tick = 0
score = 0
time = 30
game_start = false
game_pause = false
fast_mode = false
game_over = false



$text = Text.new("your score is: #{score}", x: 450, y: 30, color: 'white', style: 'bold', size: 20)
$text2 = Text.new("your time is: #{time}", x: 450, y: 60, color: 'white', style: 'bold', size: 20)


player = Rectangle.new(
  x: rand(30..570), y: rand(30..570),
  height: 30,
  width: 30,
  color: 'blue'
)



$coin = Circle.new(
  x: rand(15..585), y: rand(15..585),
  radius: 15,
  sectors: 32,
  color: 'yellow'
)


on :key_down do |event|
  fast_mode = true if event.key == 'x'
end

on :key_up do |event|
  fast_mode = false if event.key == 'x'
end

on :key_held do |event|
  speed = fast_mode ? 7 : 5

  case event.key
  when 'left' 
    player.x -= speed if player.x > 0
    player.color = 'blue'
  when 'right'
    player.x += speed if player.x + player.width < Window.width
    player.color = 'red'
  when 'down' 
    player.y += speed if player.y + player.height < Window.height
    player.color = 'orange'
  when 'up' 
    player.y -= speed if player.y > 0
    player.color = 'teal'
  end
end

def hit(player, coin)
  player_right = player.x + player.width
  player_bottom = player.y + player.height
  coin_left = coin.x - coin.radius
  coin_right = coin.x + coin.radius
  coin_top = coin.y - coin.radius
  coin_bottom = coin.y + coin.radius

  return !(player.x > coin_right || player_right < coin_left ||
           player.y > coin_bottom || player_bottom < coin_top)
end

update do

  if game_start == false
    $text.remove
    $text2.remove
    player.remove
    $coin.remove

    tutorial = Text.new("PRESS ENTER TO START", x: 0, y: 0, color: 'white', style: 'bold', size: 40)
    tutorial.x = Window.width - tutorial.width
    tutorial.y = Window.height - tutorial.height
    on :key_down do |event|
      if event.key == 'x' && !game_start
      game_start = true
      end
    end
  end

  if game_start
    tutorial.remove
  next if game_over

  if tick % 60 == 0 && time > 0
    time -= 1
    $text2.remove
    $text2 = Text.new("your time is: #{time}", x: 450, y: 60, color: 'white', style: 'bold', size: 20)
  end

  tick += 1

  if player.x < 0
    player.x = 0
  end

  if player.x > Window.width
      player.x = 0
  end

  if player.y < 0
        player.y = 0
  end

  if player.y > Window.height
          player.y = 0
  end

  if $coin && hit(player, $coin)
    $coin.remove
    $text.remove
    $coin = Circle.new(x: rand(15..585), y: rand(15..585), radius: 15, color: 'yellow')
    score += 1
    $text = Text.new("your score is: #{score}", x: 450, y: 30, color: 'white', style: 'bold', size: 20)
  end
    
    if time <= 0
      player.remove
      $coin.remove
      $text.remove
      $text2.remove
      win = Text.new("game over! your score is #{score}", x: 0, y: 0, color: 'white', style: 'bold', size: 40)
      win.x = (Window.width - win.width) / 2
      win.y = (Window.height - win.height) / 2
      game_over = true
    end
  end
end

show