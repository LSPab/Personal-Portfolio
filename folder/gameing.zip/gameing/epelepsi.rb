require 'ruby2d'

tick = 0

set width: 600
set height: 600

R1 = Rectangle.new(
  x: 0, y: 0,
  width:  300,
  height:  300
)

R2 = Rectangle.new(
  x: 0, y: 300,
  width:  300,
  height:  300
)

R3 = Rectangle.new(
  x: 300, y: 0,
  width:  300,
  height:  300
)

R4 = Rectangle.new(
  x: 300, y: 300,
  width:  300,
  height:  300
)

update do
  if tick % 1 == 0
    set background: 'random'
    R3.color = R4.color
    R4.color = R2.color
    R2.color = R1.color
    R1.color = 'random'
  end
  tick += 1
end

show